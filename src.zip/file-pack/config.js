export default {
    firstHostNameMap:{
        "fbsports":{
            targetHosts:[
                "c.e70cz.com",
                "static.fastbs111.com",
            ]
        },
    }
}