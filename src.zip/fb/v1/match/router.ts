import { Hono } from "hono";
import { fromHono } from "chanfana";
import { MatchStatistical } from "./statistical";
export const FbMatchRouter = fromHono(new Hono());


FbMatchRouter.post("/statistical",MatchStatistical)