import { OpenAPIRoute, contentJson } from "chanfana";
import { z } from "zod";
import { FbService } from "../../../service/fbService";
import { AppContext } from "../../../../types";

export class V1MatchGetMatchDetail extends OpenAPIRoute {
    public schema = {
        tags: ["V1MatchGetMatchDetail"],
        summary: "V1MatchGetMatchDetail",
        operationId: "V1MatchGetMatchDetail",
        request: {
            body: contentJson(
                z.object({
                    languageType: z.string(),
                    oddsType: z.number().or(z.string()),
                    matchId: z.any(),
                })
            ),
        },
        responses: {
            "200": {
                description: "V1MatchGetMatchDetail",
                ...contentJson({
                    code: z.any(),
                    data: z.any(),
                    success: z.boolean(),
                }),
            },
        },
    };

    async handle(c: AppContext) {
        const data = await this.getValidatedData<typeof this.schema>();
        return FbService.V1Match.getMatchDetail(data.body,c.req)
    }
}
