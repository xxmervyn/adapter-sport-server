import { OpenAPIRoute, contentJson } from "chanfana";
import { z } from "zod";
import { FbService } from "../../../service/fbService";
import { AppContext } from "../../../../types";

export class V1MatchStatistical extends OpenAPIRoute {
    public schema = {
        tags: ["V1MatchStatistical"],
        summary: "V1MatchStatistical",
        operationId: "V1MatchStatistical",
        request: {
            body: contentJson(
                z.object({
                    sportTypes: z.array(z.number()).optional(),
                    languageType: z.string(),
                    leagueId: z.number().optional(),
                    allLeague: z.boolean().optional(),
                    typeForLeagueStat: z.number().optional(),
                    markets: z.array(z.any()).optional()
                  })
            ),
        },
        responses: {
            "200": {
                description: "V1MatchStatistical",
                ...contentJson({
                    code: z.any(),
                    data: z.any(),
                    success: z.boolean(),
                }),
            },
        },
    };

    async handle(c: AppContext) {
        const data = await this.getValidatedData<typeof this.schema>();
        return FbService.V1Match.statistical(data.body,c.req)
    }
}
