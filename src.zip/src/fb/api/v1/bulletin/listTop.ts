import { OpenAPIRoute, contentJson } from "chanfana";
import { z } from "zod";
import { FbService } from "../../../service/fbService";
import { AppContext } from "../../../../types";

export class V1BulletinListTop extends OpenAPIRoute {
    public schema = {
        tags: ["V1BulletinListTop"],
        summary: "V1BulletinListTop",
        operationId: "V1BulletinListTop",
        request: {
            body: contentJson(
                z.object({
                    languageType: z.string(),
                })
            ),
        },
        responses: {
            "200": {
                description: "V1BulletinListTop",
                ...contentJson({
                    code: z.any(),
                    data: z.any(),
                    success: z.boolean(),
                }),
            },
        },
    };

    async handle(c: AppContext) {
        const data = await this.getValidatedData<typeof this.schema>();
        return FbService.V1Bulletin.listTop(data.body, c.req)
    }
}
